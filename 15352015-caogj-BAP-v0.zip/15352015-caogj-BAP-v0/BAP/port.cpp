#include <bits/stdc++.h>
#include <thread>
#include "vessel.h"
#include "port.h"
using namespace std;

static int berth_pos, import_time=0;
static int unassigned_vessels = 0, waiting_time=0, last_depart=0;
int arrange[100000], arr_pin=0;
/* For check. */
string np;
vector<int> vnp;

Port::Port()
{
  time = 20;
  berth = 12;
  memset(space, 0, sizeof(space));
  memset(port, false, sizeof(port));
} 

bool Port::Greedy_anchor(int bth, int tm, int last_berth, int last_time){
	for(int i=bth; i<last_berth+bth; i++){
		for(int j=tm; j<last_time+tm; j++){
			port[i][j] = true;
		}
	}
}

void Port::set_port(int tm, int bth){
	time = tm;
	berth = bth;
}

// clean our port;
void
Port::clean_port()
{
	for(int i=0; i<MAXX; i++){
		for(int j=0; j<MAXX; j++){
			port[i][j] = false;
		}
	}
}

// Pitch a vessel;
/*
	for(int i=bth; i<last_berth+bth; i++){
		for(int j=tm; j<last_time+tm; j++){
			port[i][j] = true;
		}
	}
*/
bool
Port::Pitch(int berth_cost, int arrival_time, int service_time)
{
	bool available=false;
	int wait_=0;
	for(int j=arrival_time; j<=time-service_time; j++){
		int contnt=0;
//		printf("Row %d\n",j);
		for(int i=0; i<=berth-berth_cost; i++){
			int pin=i;
			while(!port[pin][j]){
				contnt++;
				pin++;
				if(contnt >= berth_cost)
				{
//					printf("Row[%d] contnt=%d\n",j, contnt);
					bool ava=true;
					for(int k=i; k<i+berth_cost; k++){
						for(int u=j; u<j+service_time; u++){
							if(port[k][u]){
								ava=false;
							}
						}
						if(ava==false)	break;
					}
					if(ava){
						available = true;
						last_depart=max(last_depart, j+service_time-1);
						berth_pos = i;
						import_time=j;
						waiting_time+=wait_;
					}
					break;
				}
			}
			contnt=0;
			if(available)	break;
		}
		if(available)	break;
		wait_++;
	}
//	printf("available=");
//	cout << available << endl;
	return available;
}

// Position a vessel according to datas 'spc' and space from search;
bool Port::In_port(vessel v)
{
	int index= v.get_index();
	int arrive = v.get_arrv_tm();
	int service = v.get_serv_tm();
	int berth  = v.get_berth();
  
//   port[berth][time];
	bool available;
	available = Pitch(berth, arrive, service);
	
	if(available == false){
		
		if(v.get_index() < 10)
			np += (v.get_index()+'0');
		else
			np += ((v.get_index()-10) + 'A');
		np += '.';
		
		unassigned_vessels++;
	}else if(available == true){
		Greedy_anchor(berth_pos, import_time, berth, service);
		arrange[arr_pin++]=v.get_index();
		arrange[arr_pin++]=import_time;
		arrange[arr_pin++]=berth_pos;
	}
//	cout<<available<<endl;
//	cck();
	return available;
}

// probably accept the new sequence;
bool 
Port::accept(double delta, int temp)
{
	if(delta < 0)	return true;
	// The smaller delta is, the less the accept probablity;
	return (rand() < exp((-delta)*sqrt(temp)) * RAND_MAX);
}

// Simulated Annealing for retriving vessels;
bool
Port::Sa(vessel vessel_list[], int num)
{
	printf("\nSimulating...\n");
	/* Create temporary veriables. */
	vessel v_l[num+2];
	for(int i=0; i<num; i++)	v_l[i] = vessel_list[i];
	
	int Min_measure=2500, last_measure=2500;
	int un, wt, ls;
	int Min_arrange[100000];
	int v1=0, v2=0;
	bool Min_port[MAXX][MAXX];
	double temp=10000;
	double VesProb[num];
	//===================================
	memset(VesProb, 1.0, sizeof VesProb);
	//===================================
	for(int cnt=0; temp > 0.1;cnt++, temp *= 0.999){
		np = "";
		vnp.clear();
		arr_pin=0;
		last_depart=0;
		waiting_time=0;
		unassigned_vessels=0;
		clean_port();
		
		bool part;
		int measure;
		for(int u=0; u<10; u++){
			part=true;
			for(int i=0; i<num; i++)	In_port(v_l[i]);
	
	//		printf("Unassigned_vs=%d\n",unassigned_vessels);
	//		printf("waiting_tm=%d\n",waiting_time);
	//		printf("last_depart=%d\n", last_depart+1);
			measure = 100*unassigned_vessels+2*waiting_time+last_depart+1;
			if(measure-last_measure < 0){
				VesProb[v1] -=  0.01*sqrt( 1.0*(last_measure-measure) );
				VesProb[v2] -=  0.01*sqrt( 1.0*(last_measure-measure) );
			}
			
			if(part){
				if(measure < last_measure){
					for(int i=0; i<num; i++){
						vessel_list[i] = v_l[i];
					}
				}
				swap(v_l[(u+3)%num], v_l[u%num]);
			}else if(accept(measure-last_measure, temp))
			{
				for(int i=0; i<num; i++){
					vessel_list[i] = v_l[i];
				}
			}
			
			if(Min_measure > measure)
			{
				Min_measure = measure;
				un = unassigned_vessels;
				wt = waiting_time;
				ls = last_depart+1;
				memcpy(Min_arrange, arrange, sizeof arrange);
				memcpy(Min_port, port, sizeof port);
			}
			if(u==9){
				part = false;
				break;
			}
		}
		if(unassigned_vessels < 1){
			printf("When ALL DONE Measure=%d\n", measure);
			printf("Unassigned_vs=%d\n",unassigned_vessels);
			printf("waiting_tm=%d\n",waiting_time);
			printf("last_depart=%d\n", last_depart+1);
			cck();
			int tt[35], bb[35]; 
 			for(int i=0; i<arr_pin-2; i=i+3)
			{
//				printf("(%d,%d,%d)\n", arrange[i], arrange[i+1], arrange[i+2]);
				tt[arrange[i]]=arrange[i+1];
				bb[arrange[i]]=arrange[i+2];
			}
			for(int i=0; i<arr_pin-2; i=i+3){
				printf("%d,%d; ",bb[arrange[i]],tt[arrange[i]]);
			}printf("\n");
			break;
		}
		last_measure = measure;
		
		v1=rand()%num;
		v2=rand()%num;
		//====================================
		if(rand() > VesProb[v1]*RAND_MAX){
			v1 = (v1+rand())%num;
		}
		if(rand() > VesProb[v2]*RAND_MAX){
			v2 = (v2+rand())%num;
		}
		//====================================
		swap(v_l[v1], v_l[v2]);
		//
//		if(cnt%1000 == 0)
//			printf("min_measure = %d\n", Min_measure);
		//
	}
	
	/* Recover the datas for min case. */
//	cout << np << endl;
//	for(int i=0; i<vnp.size(); i++)
//		cout << vnp[i] << ' ';
//	cout<<endl;
	
	if(unassigned_vessels > 0){
		printf("MIN = %d\n",Min_measure);
		printf("un = %d\n", un);
		printf("wt = %d\n", wt);
		printf("ls = %d\n", ls);
		for(int i=0; i<time; i++)
			printf("-");
		printf("+\n");
		for(int i=0; i<berth; i++){
			for(int j=0; j<time; j++){
				if(Min_port[i][j]){
					printf(" ");
				}else{
					printf("+");
				}
			}printf("|\n");
		}
		for(int i=0; i<time; i++)
			printf("-");
		printf("+\n");
		printf("Here is the postion for every vessel.\n");
		
		int tt[35], bb[35]; 
		for(int i=0; i<arr_pin-2; i=i+3){
//			printf("(%d,%d,%d)\n", Min_arrange[i], Min_arrange[i+1], Min_arrange[i+2]);
			tt[arrange[i]]=arrange[i+1];
			bb[arrange[i]]=arrange[i+2];
		}
		for(int i=0; i<arr_pin-2; i=i+3){
			printf("%d,%d; ",bb[arrange[i]],tt[arrange[i]]);
		}printf("\n");
	}
	
	printf("\nFinish simulating.\n");
}

/*
Search a good place for a especialized vessel;
*/
bool
Port::retrieve(int berth_cost, int arrival_time, int service_time)
{
	bool available=false;
	int berth_point, wait_=0;
	for(int i=arrival_time; i<time; i++)
	{
		int contn_space=0, Max_contn=0;
		// calculate space continuously and make sure the point;
		for(int j=0; j < this->berth; j++)
		{
			if(!port[j][i]){
				Max_contn = max(Max_contn, ++contn_space);
				if(contn_space >= berth_cost){
				  berth_point = j-contn_space+1;
				}
			}else{
				contn_space=0;
			}
		}
		space[i] = Max_contn;
		
		wait_++;
		if(space[i] >= berth_cost){
			if(
				  !port[berth_point][i+service_time-1]
			  &&  !port[berth_point+berth_cost-1][i+service_time-1]
			  &&  (i+service_time-1)<=time-1
			  &&  (berth_point+berth_cost-1) < berth
			  )
			{
			  	bool ava=true;
			  	for(int j=berth_point; j<=berth_point+berth_cost-1; j++){
			  		for(int k=i; k<=i+service_time-1; k++){
			  			if(port[j][k]){
			  				ava=false;
			  				break;
			  			}
			  		}
			  		if(ava==false)	break;
			  	}
				if(ava){
					last_depart = max((i+service_time-1), last_depart);
					// OK;
					available=true;
					berth_pos = berth_point;
					import_time = i;
					waiting_time += (wait_-1);
					break;
				}
			}
		}
	}
	if(!available)
	{
		vnp.push_back(arrival_time);
		vnp.push_back(service_time);
		vnp.push_back(berth_cost);
	}
	return available;
}

void data_cck(){
	printf("unassigned vessels=%d\n",unassigned_vessels);
	printf("waiting_time=%d\n",waiting_time);
	printf("last_departure=%d\n",last_depart+1);
}

bool Port::cck(){
	for(int i=0; i<time; i++)
		printf("-");
	printf("+\n");
	for(int i=0; i<berth; i++){
		for(int j=0; j<time; j++){
			if(port[i][j]){
				printf(" ");
			}else{
				printf("+");
			}
		}printf("|\n");
	}
	for(int i=0; i<time; i++)
		printf("-");
	printf("+\n");
//	data_cck();
	return true;
}

