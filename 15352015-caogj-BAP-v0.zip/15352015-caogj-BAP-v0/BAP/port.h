#include <bits/stdc++.h>
#define MAXX 35
using namespace std;

class Port{
public:
	Port();
	void set_port(int time, int berth);
	void clean_port();
	bool In_port(vessel v);
	bool Sa(vessel vessel_list[], int num);
	bool cck();
protected:
	int time, berth;
	bool port[MAXX][MAXX];
private:
	bool retrieve(int berth, int arrival_time, int service_time);
	bool Pitch(int berth_cost, int arrival_time, int service_time);
	bool Greedy_anchor(int berth, int time, int last_berth, int last_time);
	bool accept(double delta, int temp);
	int space[MAXX];
//	int spc_;
};
