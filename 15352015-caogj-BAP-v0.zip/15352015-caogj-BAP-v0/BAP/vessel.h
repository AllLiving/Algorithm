#include <iostream>
using namespace std;

class vessel{
public:
	vessel();
	void set_vessel(int index, int arrival_time, int service_time, int berth);
	int get_index();
	int get_arrv_tm();
	int get_serv_tm();
	int get_berth();
	
	void check();
protected:
	int index;
	int arrival_time;
	int service_time;
	int berth;
}; 
