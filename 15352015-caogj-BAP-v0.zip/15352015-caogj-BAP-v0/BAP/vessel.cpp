#include "vessel.h"
using namespace std;

vessel::vessel(){
	index = 0;
	arrival_time = 0;
	service_time = 0;
	berth = 1;
}

void vessel::set_vessel(int idx, int atm, int stm, int bth)
{
  index = idx;
  arrival_time = atm;
  service_time = stm;
  berth = bth;
}

int vessel::get_arrv_tm()
{
  return arrival_time;
}

int vessel::get_berth()
{
  return berth;
}

int vessel::get_index()
{
  return index;
}

int vessel::get_serv_tm()
{
  return service_time;
}

void vessel::check(){
	cout << index << endl;
}
