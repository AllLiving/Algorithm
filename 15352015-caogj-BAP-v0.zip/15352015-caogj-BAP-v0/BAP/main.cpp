#include <iostream>
#include <vector>
#include "vessel.h"
#include "Port.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
mutex m;
void delay(){
	m.lock();
	printf("delay.\n");
	m.unlock();
}

int main(int argc, char** argv) {
	while(1){
	/* Create a port. */
	int berth_container, service_time;
	cin >> service_time >> berth_container;
	
	Port p;
	p.set_port(service_time, berth_container);
	
	/* Reserve vessel space for costumers. */
	vessel v_list[35];
	
	int index=0, cnt=0;
	
	int N;	
	cin >> N;
	while(N--){
		int arrv_tm, serv_tm, berth;
		cin >> arrv_tm;
		cin >> serv_tm;
		cin >> berth;
		
		vessel v;
		v.set_vessel(++index, arrv_tm, serv_tm, berth);
//		p.In_port(v);
		v_list[cnt++]=v;
	}
	
	/* Begin calculation. */
	srand(time(0));
	thread(delay);
	m.lock();
	p.Sa(v_list, cnt);
	m.unlock();
//	system("PAUSE");
}
	return 0;
}
